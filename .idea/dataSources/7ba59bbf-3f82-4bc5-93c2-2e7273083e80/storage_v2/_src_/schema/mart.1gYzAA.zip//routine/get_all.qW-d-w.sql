create
    definer = root@localhost procedure get_all()
BEGIN
  SELECT * FROM product WHERE 가격 > 6000;
END;

