create
    definer = root@localhost function delivery(가격 int) returns int deterministic
BEGIN
	RETURN IF(가격 >= 5000, 가격, 가격 + 3000);
END;

