create
    definer = root@localhost function calendar(num int) returns int deterministic
BEGIN 
	IF num IN (1,3,5,7,8,10,12) THEN
		RETURN 31;
	ELSEIF num IN (4,6,9,11) THEN
		RETURN 30;
	ELSEIF num = 2 THEN 
		RETURN 28;
	ELSE
		RETURN 0;		
	END IF;
	
END;

