create
    definer = root@localhost procedure test()
BEGIN
	
	IF (SELECT sum(사용금액) FROM mart.card) > 5000000 THEN
		SELECT '잘했어요';
	ELSE 
		SELECT '분발하세요';
	END IF;
	
	
END;

