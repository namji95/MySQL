create
    definer = root@localhost procedure get_age(OUT var_age int)
BEGIN
	SET var_age = 20;
END;

