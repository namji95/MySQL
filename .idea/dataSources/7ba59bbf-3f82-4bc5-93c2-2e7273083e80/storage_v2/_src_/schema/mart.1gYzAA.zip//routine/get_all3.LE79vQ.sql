create
    definer = root@localhost procedure get_all3(IN 파라미터 int, IN 파라미터2 varchar(100))
BEGIN
  SELECT * FROM product WHERE 가격 > 파라미터 OR 카테고리 = 파라미터2;
END;

