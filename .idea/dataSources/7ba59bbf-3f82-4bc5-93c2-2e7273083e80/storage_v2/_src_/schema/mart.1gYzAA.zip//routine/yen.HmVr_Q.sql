create
    definer = root@localhost function yen(가격 int) returns int deterministic
BEGIN
	RETURN 가격 * 0.1 + 50;
END;

