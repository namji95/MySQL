create
    definer = root@localhost procedure add_one()
BEGIN
	INSERT INTO product (번호, 상품명, 카테고리, 가격, 재고) VALUES (14, '원목 의자', '가구', 2000, 30);
END;

