create
    definer = root@localhost procedure proced(IN 입력 varchar(100))
BEGIN
	IF 입력 = '평균' THEN
		SELECT avg(사용금액) FROM mart.card;
	ELSEIF 입력 = '최댓값' THEN
		SELECT max(사용금액) FROM mart.card;
	ELSEIF 입력 = '최빈값' THEN
		SELECT 고객등급, count(고객등급) FROM mart.card
		GROUP BY 고객등급 ORDER BY count(고객등급) DESC LIMIT 1; 		
	END IF;
	
END;

