create
    definer = root@localhost procedure var_test()
BEGIN
	DECLARE 변수1 int DEFAULT 123;
	DECLARE 변수2 varchar(100) DEFAULT '안녕하세요';
	SELECT 변수1;
	SELECT 변수2;
END;

