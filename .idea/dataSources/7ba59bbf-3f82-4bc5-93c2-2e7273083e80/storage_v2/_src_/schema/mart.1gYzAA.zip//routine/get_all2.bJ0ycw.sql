create
    definer = root@localhost procedure get_all2(IN 파라미터 int)
BEGIN
  SELECT * FROM product WHERE 가격 > 파라미터;
END;

