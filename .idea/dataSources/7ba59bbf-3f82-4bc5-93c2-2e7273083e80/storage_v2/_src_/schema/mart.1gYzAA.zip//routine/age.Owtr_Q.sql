create
    definer = root@localhost function age(나이 int) returns varchar(100) deterministic
BEGIN
	
	IF 나이 < 20 THEN
		RETURN '미성년자에요';
	ELSE 
		RETURN '미성년자 아니에요';
	END IF;
	
END;

