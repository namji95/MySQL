create definer = root@localhost trigger counterUp
    after insert
    on product
    for each row
BEGIN

	UPDATE trigger_test.counter SET 값 = 값 + 1 WHERE 자료 = '상품갯수';

END;

